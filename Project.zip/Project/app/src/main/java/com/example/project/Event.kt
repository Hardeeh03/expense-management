package com.example.project

data class Event(
    val id: Int,
    val purpose: String,
    val amount: Double,
    val date: String
)