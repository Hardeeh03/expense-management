package com.example.project

interface StatisticsDataProvider {
    fun getTotalSum(): Double
    // Add more methods as needed for additional statistics data
}